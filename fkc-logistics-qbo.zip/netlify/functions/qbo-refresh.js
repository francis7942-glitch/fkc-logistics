// netlify/functions/qbo-refresh.js
// Refreshes QBO access token using refresh token stored in Supabase

const { createClient } = require('@supabase/supabase-js');

async function refreshTokens(supabase, tokenRow) {
  const CLIENT_ID     = process.env.QBO_CLIENT_ID;
  const CLIENT_SECRET = process.env.QBO_CLIENT_SECRET;

  const res = await fetch('https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64'),
      'Accept': 'application/json',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: tokenRow.refresh_token,
    }).toString(),
  });

  const tokens = await res.json();
  if (!tokens.access_token) throw new Error('Token refresh failed: ' + JSON.stringify(tokens));

  const updated = {
    ...tokenRow,
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token || tokenRow.refresh_token,
    expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
  };

  await supabase.from('qbo_tokens').upsert(updated);
  return updated;
}

// Get a valid access token (refreshes if expired)
async function getValidToken(supabase) {
  const { data, error } = await supabase.from('qbo_tokens').select('*').eq('id', 'default').single();
  if (error || !data) throw new Error('QBO not connected. Please connect QuickBooks first.');

  const expiresAt = new Date(data.expires_at);
  const now = new Date();
  const isExpired = (expiresAt - now) < 5 * 60 * 1000; // refresh if < 5 min left

  if (isExpired) {
    return await refreshTokens(supabase, data);
  }
  return data;
}

module.exports = { getValidToken };
